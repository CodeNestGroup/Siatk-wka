export type PlayerStatus = "main" | "waitlist"

export type Player = {
  id: string
  name: string
  registeredAt: string
  paid: boolean
  fee: number
  method: "gotówka" | "online"
  skill: number // 1-5 used by the team balancer
}

export type MatchStatus = "upcoming" | "past"

export type Match = {
  id: string
  date: string
  startTime: string
  endTime: string
  location: string
  capacity: number
  fee: number
  status: MatchStatus
  rating: number
  players: Player[]
}

export type Sponsor = {
  id: string
  name: string
  tier: "Tytularny" | "Główny" | "Partner"
  logo: string
  contractUntil: string
  banner: "Ekran startowy" | "Baner meczowy" | "Stopka" | "Karta zawodnika"
  annual: number
  active: boolean
}

export type Announcement = {
  id: string
  title: string
  body: string
  audience: "Wszyscy" | "Lista główna" | "Lista rezerwowa"
  date: string
  pinned: boolean
}

const firstNames = [
  "Kuba", "Marta", "Piotr", "Ola", "Tomek", "Ania", "Michał", "Kasia",
  "Bartek", "Zosia", "Adam", "Ewa", "Filip", "Nina", "Wojtek", "Lena",
  "Damian", "Iga",
]

const lastNames = [
  "Nowak", "Kowalski", "Wiśniewska", "Wójcik", "Kamiński", "Lewandowska",
  "Zieliński", "Szymańska", "Woźniak", "Dąbrowski", "Kozłowska", "Mazur",
  "Krawczyk", "Piotrowska", "Grabowski", "Pawlak", "Michalska", "Król",
]

function makePlayers(count: number, fee: number, paidRatio: number): Player[] {
  return Array.from({ length: count }).map((_, i) => {
    const hour = 14 + Math.floor(i / 4)
    const minute = (i % 4) * 12
    const paid = i / count < paidRatio
    return {
      id: `p-${i}`,
      name: `${firstNames[i % firstNames.length]} ${lastNames[i % lastNames.length]}`,
      registeredAt: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
      paid,
      fee,
      method: (i % 3 === 0 ? "gotówka" : "online") as Player["method"],
      skill: ((i * 7) % 5) + 1,
    }
  })
}

export const matches: Match[] = [
  {
    id: "m-1",
    date: "2026-07-28",
    startTime: "19:00",
    endTime: "21:00",
    location: "Hala Główna",
    capacity: 12,
    fee: 20,
    status: "upcoming",
    rating: 0,
    players: makePlayers(15, 20, 0.6),
  },
  {
    id: "m-2",
    date: "2026-07-30",
    startTime: "18:00",
    endTime: "20:00",
    location: "Hala Zachodnia",
    capacity: 12,
    fee: 20,
    status: "upcoming",
    rating: 0,
    players: makePlayers(8, 20, 0.5),
  },
  {
    id: "m-3",
    date: "2026-08-02",
    startTime: "20:00",
    endTime: "22:00",
    location: "Hala Nadrzeczna",
    capacity: 12,
    fee: 25,
    status: "upcoming",
    rating: 0,
    players: makePlayers(14, 25, 0.35),
  },
  {
    id: "m-4",
    date: "2026-07-21",
    startTime: "19:00",
    endTime: "21:00",
    location: "Hala Główna",
    capacity: 12,
    fee: 20,
    status: "past",
    rating: 5,
    players: makePlayers(12, 20, 1),
  },
  {
    id: "m-5",
    date: "2026-07-18",
    startTime: "18:30",
    endTime: "20:30",
    location: "Hala Zachodnia",
    capacity: 12,
    fee: 20,
    status: "past",
    rating: 4,
    players: makePlayers(12, 20, 0.92),
  },
  {
    id: "m-6",
    date: "2026-07-14",
    startTime: "20:00",
    endTime: "22:00",
    location: "Hala Nadrzeczna",
    capacity: 10,
    fee: 25,
    status: "past",
    rating: 3,
    players: makePlayers(10, 25, 1),
  },
]

export const sponsors: Sponsor[] = [
  {
    id: "s-1",
    name: "ESCO",
    tier: "Tytularny",
    logo: "/sponsors/esco.png",
    contractUntil: "2027-06-30",
    banner: "Ekran startowy",
    annual: 48000,
    active: true,
  },
  {
    id: "s-2",
    name: "SportBank",
    tier: "Główny",
    logo: "/sponsors/sportbank.png",
    contractUntil: "2026-12-31",
    banner: "Baner meczowy",
    annual: 24000,
    active: true,
  },
  {
    id: "s-3",
    name: "Falcon",
    tier: "Partner",
    logo: "/sponsors/falcon.png",
    contractUntil: "2026-08-31",
    banner: "Karta zawodnika",
    annual: 9000,
    active: true,
  },
]

export const announcements: Announcement[] = [
  {
    id: "a-1",
    title: "Zmiana hali w środę",
    body: "Mecz 30.07 zostaje przeniesiony do Hali Zachodniej. Wejście od strony parkingu.",
    audience: "Lista główna",
    date: "2026-07-26",
    pinned: true,
  },
  {
    id: "a-2",
    title: "Zwolniło się miejsce!",
    body: "Jedna osoba zrezygnowała z meczu 28.07 — pierwsza osoba z listy rezerwowej awansuje automatycznie.",
    audience: "Lista rezerwowa",
    date: "2026-07-25",
    pinned: false,
  },
  {
    id: "a-3",
    title: "Nowy sponsor tytularny",
    body: "Witamy ESCO jako sponsora tytularnego ligi na sezon 2026/2027. Dziękujemy za wsparcie!",
    audience: "Wszyscy",
    date: "2026-07-20",
    pinned: false,
  },
]

export const monthlyIncome: { month: string; cash: number; online: number }[] = [
  { month: "Lut", cash: 320, online: 480 },
  { month: "Mar", cash: 410, online: 690 },
  { month: "Kwi", cash: 380, online: 720 },
  { month: "Maj", cash: 460, online: 880 },
  { month: "Cze", cash: 520, online: 960 },
  { month: "Lip", cash: 610, online: 1140 },
]

export function mainRoster(match: Match): Player[] {
  return match.players.slice(0, match.capacity)
}

export function waitlist(match: Match): Player[] {
  return match.players.slice(match.capacity)
}

export function paidCount(match: Match): number {
  return mainRoster(match).filter((p) => p.paid).length
}

export function collected(match: Match): number {
  return mainRoster(match)
    .filter((p) => p.paid)
    .reduce((sum, p) => sum + p.fee, 0)
}

export function expected(match: Match): number {
  return mainRoster(match).reduce((sum, p) => sum + p.fee, 0)
}

/** Splits the main roster into two balanced teams based on skill rating. */
export function balanceTeams(match: Match): { a: Player[]; b: Player[] } {
  const sorted = [...mainRoster(match)].sort((p1, p2) => p2.skill - p1.skill)
  const a: Player[] = []
  const b: Player[] = []
  let sumA = 0
  let sumB = 0
  for (const p of sorted) {
    if (sumA <= sumB) {
      a.push(p)
      sumA += p.skill
    } else {
      b.push(p)
      sumB += p.skill
    }
  }
  return { a, b }
}

export function formatDate(iso: string): string {
  const d = new Date(iso + "T00:00:00")
  return d.toLocaleDateString("pl-PL", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  })
}

export function formatWeekday(iso: string): string {
  const d = new Date(iso + "T00:00:00")
  return d.toLocaleDateString("pl-PL", { weekday: "long" })
}
