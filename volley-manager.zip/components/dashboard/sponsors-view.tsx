"use client"

import Image from "next/image"
import {
  Handshake,
  Plus,
  CalendarClock,
  MonitorSmartphone,
  Banknote,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "./ui-bits"
import { sponsors, type Sponsor, formatDate } from "@/lib/data"

const tierTone: Record<Sponsor["tier"], "info" | "success" | "warning"> = {
  Tytularny: "info",
  Główny: "success",
  Partner: "warning",
}

export function SponsorsView({ notify }: { notify: (msg: string) => void }) {
  const totalAnnual = sponsors.reduce((sum, s) => sum + s.annual, 0)
  const activeCount = sponsors.filter((s) => s.active).length

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Sponsorzy i Partnerzy
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Zarządzaj umowami, logotypami i pozycją banerów w aplikacji mobilnej.
          </p>
        </div>
        <Button
          size="lg"
          className="gap-2"
          onClick={() => notify("Formularz nowego sponsora otwarty")}
        >
          <Plus className="h-4 w-4" />
          Dodaj sponsora
        </Button>
      </div>

      {/* Titular banner preview */}
      <div className="overflow-hidden rounded-2xl border border-border bg-sidebar p-6 text-sidebar-foreground">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/60">
              Sponsor tytularny
            </p>
            <h2 className="mt-1 text-xl font-bold text-sidebar-primary-foreground">
              Liga ESCO · sezon 2026/2027
            </h2>
            <p className="mt-1 text-sm text-sidebar-foreground/70">
              Baner wyświetlany na ekranie startowym aplikacji mobilnej.
            </p>
          </div>
          <div className="flex h-16 items-center rounded-xl bg-background px-6">
            <Image
              src="/sponsors/esco.png"
              alt="Logo sponsora ESCO"
              width={140}
              height={44}
              className="h-10 w-auto object-contain"
            />
          </div>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <SummaryCard
          label="Aktywni sponsorzy"
          value={String(activeCount)}
          icon={Handshake}
          tone="bg-primary/10 text-primary"
        />
        <SummaryCard
          label="Roczny przychód"
          value={`${totalAnnual.toLocaleString("pl-PL")} zł`}
          icon={Banknote}
          tone="bg-success/12 text-success"
        />
        <SummaryCard
          label="Umowy w tym roku"
          value={String(sponsors.length)}
          icon={CalendarClock}
          tone="bg-warning/20 text-warning-foreground"
        />
      </div>

      {/* Sponsor cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {sponsors.map((s) => (
          <div
            key={s.id}
            className="flex flex-col rounded-2xl border border-border bg-card p-5 shadow-sm"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex h-14 w-32 items-center justify-center overflow-hidden rounded-lg border border-border bg-background px-3">
                <Image
                  src={s.logo || "/placeholder.svg"}
                  alt={`Logo sponsora ${s.name}`}
                  width={120}
                  height={40}
                  className="h-9 w-auto object-contain"
                />
              </div>
              <Badge tone={tierTone[s.tier]}>{s.tier}</Badge>
            </div>

            <h3 className="mt-4 text-base font-bold text-foreground">{s.name}</h3>

            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <CalendarClock className="h-4 w-4" />
                <dt className="sr-only">Umowa do</dt>
                <dd>Umowa do {formatDate(s.contractUntil)}</dd>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MonitorSmartphone className="h-4 w-4" />
                <dt className="sr-only">Pozycja banera</dt>
                <dd>{s.banner}</dd>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Banknote className="h-4 w-4" />
                <dt className="sr-only">Wartość roczna</dt>
                <dd className="font-medium text-foreground">
                  {s.annual.toLocaleString("pl-PL")} zł / rok
                </dd>
              </div>
            </dl>

            <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
              <span className="flex items-center gap-1.5 text-xs font-medium text-success">
                <span className="h-2 w-2 rounded-full bg-success" />
                Aktywna umowa
              </span>
              <button
                onClick={() => notify(`Edytujesz umowę: ${s.name}`)}
                className="text-xs font-semibold text-primary hover:underline"
              >
                Zarządzaj
              </button>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}

function SummaryCard({
  label,
  value,
  icon: Icon,
  tone,
}: {
  label: string
  value: string
  icon: typeof Handshake
  tone: string
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        <span
          className={`flex h-9 w-9 items-center justify-center rounded-lg ${tone}`}
        >
          <Icon className="h-[18px] w-[18px]" />
        </span>
      </div>
      <p className="mt-3 text-2xl font-bold tracking-tight text-foreground">
        {value}
      </p>
    </div>
  )
}
