"use client"

import Image from "next/image"
import {
  CalendarDays,
  Users,
  Wallet,
  BarChart3,
  Megaphone,
  Handshake,
  Volleyball,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { sponsors } from "@/lib/data"

export type TabKey =
  | "matches"
  | "players"
  | "finance"
  | "statistics"
  | "announcements"
  | "sponsors"

const navItems: { key: TabKey; label: string; icon: typeof CalendarDays; badge?: string }[] = [
  { key: "matches", label: "Mecze", icon: CalendarDays },
  { key: "players", label: "Zawodnicy", icon: Users },
  { key: "finance", label: "Finanse", icon: Wallet, badge: "Nowość" },
  { key: "statistics", label: "Statystyki", icon: BarChart3 },
  { key: "announcements", label: "Ogłoszenia", icon: Megaphone },
  { key: "sponsors", label: "Sponsorzy", icon: Handshake },
]

export function Sidebar({
  open,
  onClose,
  activeTab,
  onTabChange,
}: {
  open: boolean
  onClose: () => void
  activeTab: TabKey
  onTabChange: (tab: TabKey) => void
}) {
  const titular = sponsors.find((s) => s.tier === "Tytularny")

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-40 bg-foreground/40 lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-72 flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300 lg:static lg:z-auto lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between gap-3 px-6 py-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground">
              <Volleyball className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <p className="font-semibold text-sidebar-primary-foreground">
                VolleyManager
              </p>
              <p className="text-xs text-sidebar-foreground/70">Liga ESCO</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground lg:hidden"
            aria-label="Zamknij nawigację"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 px-4">
          {navItems.map((item) => {
            const Icon = item.icon
            const active = item.key === activeTab
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => {
                  onTabChange(item.key)
                  onClose()
                }}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <Icon className="h-[18px] w-[18px] shrink-0" />
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge && (
                  <span className="rounded-full bg-success px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-success-foreground">
                    {item.badge}
                  </span>
                )}
              </button>
            )
          })}
        </nav>

        {/* Sponsor tytularny widget */}
        {titular && (
          <button
            type="button"
            onClick={() => {
              onTabChange("sponsors")
              onClose()
            }}
            className="mx-4 mt-4 rounded-xl border border-sidebar-border bg-sidebar-accent/60 p-3 text-left transition-colors hover:bg-sidebar-accent"
          >
            <p className="text-[10px] font-semibold uppercase tracking-wide text-sidebar-foreground/60">
              Sponsor tytularny
            </p>
            <div className="mt-2 flex items-center gap-2">
              <span className="flex h-9 flex-1 items-center justify-center overflow-hidden rounded-md bg-background px-2">
                <Image
                  src={titular.logo || "/placeholder.svg"}
                  alt={`Logo sponsora ${titular.name}`}
                  width={96}
                  height={28}
                  className="h-6 w-auto object-contain"
                />
              </span>
            </div>
          </button>
        )}

        <div className="m-4 flex items-center gap-3 rounded-xl bg-sidebar-accent p-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-primary text-sm font-semibold text-sidebar-primary-foreground">
            AK
          </div>
          <div className="min-w-0 flex-1 leading-tight">
            <p className="truncate text-sm font-medium text-sidebar-accent-foreground">
              Adam Kowalski
            </p>
            <p className="text-xs text-sidebar-foreground/70">Tryb administratora</p>
          </div>
          <span className="h-2.5 w-2.5 rounded-full bg-success" aria-hidden="true" />
        </div>
      </aside>
    </>
  )
}
