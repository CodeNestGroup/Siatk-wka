"use client"

import { useMemo, useState } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { StatCards } from "./stat-cards"
import { MatchList } from "./match-list"
import { MatchDetail } from "./match-detail"
import { CreateMatch } from "./create-match"
import {
  type Match,
  collected as matchCollected,
  mainRoster,
} from "@/lib/data"
import { cn } from "@/lib/utils"

type Filter = "all" | "upcoming" | "past"

export function MatchesView({
  matches,
  onUpdateMatch,
  onDeleteMatch,
  onCreateMatch,
  notify,
}: {
  matches: Match[]
  onUpdateMatch: (m: Match) => void
  onDeleteMatch: (m: Match) => void
  onCreateMatch: (m: Match) => void
  notify: (msg: string) => void
}) {
  const [filter, setFilter] = useState<Filter>("all")
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)

  const selected = matches.find((m) => m.id === selectedId) ?? null

  const filtered = useMemo(
    () => matches.filter((m) => (filter === "all" ? true : m.status === filter)),
    [matches, filter],
  )

  const stats = useMemo(() => {
    const played = matches.filter((m) => m.status === "past")
    const upcoming = matches.filter((m) => m.status === "upcoming")
    const monthCollected = matches.reduce((sum, m) => sum + matchCollected(m), 0)
    const conversions = matches.reduce(
      (sum, m) => sum + Math.max(0, mainRoster(m).length - m.capacity + 3),
      0,
    )
    return {
      played: played.length,
      upcoming: upcoming.length,
      collected: monthCollected,
      conversions: Math.min(conversions, 9),
    }
  }, [matches])

  function createMatch(match: Match) {
    onCreateMatch(match)
    setCreating(false)
  }

  const filters: { key: Filter; label: string }[] = [
    { key: "all", label: "Wszystkie" },
    { key: "upcoming", label: "Nadchodzące" },
    { key: "past", label: "Rozegrane" },
  ]

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Zarządzanie Meczami
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Śledź składy, listy rezerwowe i opłaty w każdej sesji.
          </p>
        </div>
        <Button size="lg" className="gap-2" onClick={() => setCreating(true)}>
          <Plus className="h-4 w-4" />
          Utwórz nowy mecz
        </Button>
      </div>

      <StatCards
        totalPlayed={stats.played}
        upcoming={stats.upcoming}
        collected={stats.collected}
        conversions={stats.conversions}
      />

      <div className="flex items-center gap-1 rounded-xl border border-border bg-card p-1 w-fit">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              "rounded-lg px-4 py-1.5 text-sm font-medium transition-colors",
              filter === f.key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card p-12 text-center">
          <p className="text-sm text-muted-foreground">
            Brak meczów w tym widoku.
          </p>
        </div>
      ) : (
        <MatchList
          matches={filtered}
          onSelect={(m) => setSelectedId(m.id)}
          onNotify={(m) =>
            notify(`Powiadomienie wysłane do ${mainRoster(m).length} zapisanych zawodników`)
          }
          onDelete={(m) => {
            onDeleteMatch(m)
            notify("Mecz usunięty")
          }}
        />
      )}

      {selected && (
        <MatchDetail
          match={selected}
          onChange={onUpdateMatch}
          onClose={() => setSelectedId(null)}
          notify={notify}
        />
      )}

      {creating && (
        <CreateMatch onCreate={createMatch} onClose={() => setCreating(false)} />
      )}
    </>
  )
}
