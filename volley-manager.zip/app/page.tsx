"use client"

import { useState } from "react"
import { Menu, Search, Bell, CheckCircle2 } from "lucide-react"
import { Sidebar, type TabKey } from "@/components/dashboard/sidebar"
import { MatchesView } from "@/components/dashboard/matches-view"
import { FinanceView } from "@/components/dashboard/finance-view"
import { PlayersView } from "@/components/dashboard/players-view"
import { StatisticsView } from "@/components/dashboard/statistics-view"
import { AnnouncementsView } from "@/components/dashboard/announcements-view"
import { SponsorsView } from "@/components/dashboard/sponsors-view"
import { matches as seedMatches, type Match } from "@/lib/data"

export default function DashboardPage() {
  const [matches, setMatches] = useState<Match[]>(seedMatches)
  const [activeTab, setActiveTab] = useState<TabKey>("matches")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  function notify(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(null), 2500)
  }

  function updateMatch(updated: Match) {
    setMatches((prev) => prev.map((m) => (m.id === updated.id ? updated : m)))
  }

  function deleteMatch(match: Match) {
    setMatches((prev) => prev.filter((m) => m.id !== match.id))
  }

  function createMatch(match: Match) {
    setMatches((prev) => [match, ...prev])
    notify("Mecz utworzony")
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur lg:px-8">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-lg p-2 text-muted-foreground hover:bg-secondary lg:hidden"
            aria-label="Otwórz nawigację"
          >
            <Menu className="h-5 w-5" />
          </button>

          <div className="relative hidden flex-1 max-w-sm md:block">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              placeholder="Szukaj meczów, zawodników…"
              className="w-full rounded-lg border border-input bg-card py-2 pl-9 pr-3 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-ring focus:ring-2 focus:ring-ring/30"
            />
          </div>

          <div className="ml-auto flex items-center gap-2">
            <button
              className="relative rounded-lg p-2 text-muted-foreground hover:bg-secondary"
              aria-label="Powiadomienia"
            >
              <Bell className="h-5 w-5" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-destructive" />
            </button>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
              AK
            </div>
          </div>
        </header>

        <main className="mx-auto w-full max-w-7xl flex-1 space-y-6 px-4 py-6 lg:px-8">
          {activeTab === "matches" && (
            <MatchesView
              matches={matches}
              onUpdateMatch={updateMatch}
              onDeleteMatch={deleteMatch}
              onCreateMatch={createMatch}
              notify={notify}
            />
          )}
          {activeTab === "finance" && (
            <FinanceView matches={matches} notify={notify} />
          )}
          {activeTab === "players" && <PlayersView matches={matches} />}
          {activeTab === "statistics" && <StatisticsView matches={matches} />}
          {activeTab === "announcements" && (
            <AnnouncementsView notify={notify} />
          )}
          {activeTab === "sponsors" && <SponsorsView notify={notify} />}
        </main>
      </div>

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 rounded-full bg-foreground px-4 py-2.5 text-sm font-medium text-background shadow-lg">
          <CheckCircle2 className="h-4 w-4 text-success" />
          {toast}
        </div>
      )}
    </div>
  )
}
